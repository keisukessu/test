package jp.ac.ritsumei.ise.phy.exp2.is0674hk.final_kadai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.Image;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;

public class MySurfaceView extends SurfaceView implements Runnable,SurfaceHolder.Callback{
    private SurfaceHolder sHolder ; // SurfaceHolder を格納
    private Thread thread ; /* Thread クラスのインスタンスを準備 */

    public MySurfaceView(Context context) {
        super(context);
        initialize() ;
    }
    public MySurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize() ;
    }
    public MySurfaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize() ;
    }

    public MySurfaceView(Context context, AttributeSet attrs, int defStyleAttr,
                         int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initialize() ;
    }
    private void initialize() {
        sHolder = getHolder() ; // SurfaceHolder を取得
        sHolder.addCallback(this) ; // 自身をコールバックとして登録
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread = new Thread(this) ; /* 新しくスレッドを作成 */
        thread.start() ; /* スレッドをスタートさせる */
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        thread = null ; /* スレッドを停止させる */
    }

    static final long FPS = 30 ;
    static final long FTIME = 1000 / FPS ;
    @Override
    public void run() {
        long loopC = 0 ; // ループ数のカウンタ
        long wTime = 0 ; // 次の描画までの待ち時間（ミリ秒）
        /* 必要に応じて描画に関する初期化をここに書く */
        long sTime = System.currentTimeMillis() ; // 開始時の現在時刻
        while (thread != null) {
            try {
                loopC++ ;
                drawCanvas() ; /* drawCanvas メソッドで画面を描画 */
                wTime = (loopC * FTIME) - (System.currentTimeMillis() - sTime) ;
                if (wTime > 0) {
                    Thread.sleep(wTime) ;
                }
            } catch (InterruptedException e) {
                /* 必要に応じて割り込み発生時の例外処理を追加 */
            }


        }}
    public static float x = 0 ;
    public static float y = 0 ;
    public static float y1=0;
    public static float dx = 0 ;//x方向の変化量
    public static float dy = 0 ;//y方向の変化量
    public static float dy1 = 45;
    public static float imgR = 150; // 画像の半径
    public static float imgR_a = 100; // 相手画像の半径
    public  static float rnd_x=(float)Math.random()*(1080-2*imgR_a);
    public static boolean flag=false;

    Paint p = new Paint() ;
    private void drawCanvas() {
        Canvas c = sHolder.lockCanvas() ;
        c.drawColor(Color.BLACK) ;
        float imgX = c.getWidth() / 2;
        float imgY = c.getHeight() / 2;
        x+=dx;//x方向の移動
        y+=dy;//y方向の移動
        y1+=dy1;

        //画像の中心座標
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.kawara); // 画像のリソースを指定
        Bitmap resized_bitmap=Bitmap.createScaledBitmap(bitmap,300,300,true);
        c.drawBitmap(resized_bitmap, (imgX - imgR)+x, (2*imgY - 2*imgR)+y, p);

        //相手画像の中心座標
        Bitmap bitmap_a = BitmapFactory.decodeResource(getResources(), R.drawable.atyo1); // 画像のリソースを指定
        Bitmap resized_bitmap_a=Bitmap.createScaledBitmap(bitmap_a,200,200,true);
        c.drawBitmap(resized_bitmap_a, rnd_x, -imgR_a + y1, p);

        MainActivity.restart_button.setVisibility(View.INVISIBLE);
        //画像を再生成
        if(y1>2*imgY) {
            rnd_x=(float)Math.random()*(1080-2*imgR_a);
            y1=0;
        }

        //円が左右の壁に接触した際に移動方向を反転
        if (x<=-c.getWidth()/2+imgR||x>=c.getWidth()/2-imgR){
            dx*=-1;
        }
        //円が上下の壁に接触した際に移動方向を反転
        if(y<=-c.getHeight()+2*imgR||y>0){
            dy*=-1;
        }

        //画像の中心座標
        float center_w=(imgX - imgR)+x+imgR;
        float center_h=(2*imgY - 2*imgR)+y+imgR;
        float center_a_w=rnd_x+imgR_a;
        float center_a_h=-imgR_a + y1+imgR_a;
        //当たり判定
        if((Math.abs(center_w-center_a_w)<imgR+imgR_a)&&(Math.abs(center_h-center_a_h)<imgR+imgR_a)){
            dx=0;
            dy=0;
            dy1=0;
            flag=true;

            // 衝突後、ボタンを表示
            MainActivity.restart_button.post(new Runnable() {
                @Override
                public void run() {
                    if(MySurfaceView.flag){
                        MainActivity.restart_button.setVisibility(View.VISIBLE);
                    }

                }
            });
        }


        //衝突後画像を表示
        if(flag){
            Bitmap bitmap_phonto = BitmapFactory.decodeResource(getResources(), R.drawable.phonto); // 画像のリソースを指定
            Bitmap resized_bitmap_phonto=Bitmap.createScaledBitmap(bitmap_phonto,1000,300,true);
            c.drawBitmap(resized_bitmap_phonto, 50, 400, p);
            Bitmap bitmap_kawarawari = BitmapFactory.decodeResource(getResources(), R.drawable.kawarawari); // 画像のリソースを指定
            Bitmap resized_bitmap_kawarawari=Bitmap.createScaledBitmap(bitmap_kawarawari,1000,700,true);
            c.drawBitmap(resized_bitmap_kawarawari, 50, 700, p);
        }
        sHolder.unlockCanvasAndPost(c);
}}
package jp.ac.ritsumei.ise.phy.exp2.is0674hk.final_kadai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
//    private MySurfaceView mySurfaceView;
    private ImageButton Lbutton,Rbutton,Ubutton,Dbutton;
    public static Button restart_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // SurfaceViewを取得
//        mySurfaceView = findViewById(R.id.mySurfaceView);

        // ボタンを取得
        Lbutton = findViewById(R.id.Lbutton);
        Rbutton = findViewById(R.id.Rbutton);
        Ubutton = findViewById(R.id.Ubutton);
        Dbutton = findViewById(R.id.Dbutton);
        restart_button=findViewById(R.id.restart_button);

        // ボタンのクリックリスナーを設定
        Lbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MySurfaceView.dx=-15;
                MySurfaceView.dy=0;
            }
        });
        Rbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MySurfaceView.dx=15;
                MySurfaceView.dy=0;
            }
        });
        Ubutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MySurfaceView.dx=0;
                MySurfaceView.dy=-60;
            }
        });
        Dbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MySurfaceView.dx=0;
                MySurfaceView.dy=60;
            }
        });
        restart_button.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v) {
              MySurfaceView.x=0;
              MySurfaceView.y=0;
              MySurfaceView.rnd_x=(float)Math.random()*(1080-2*MySurfaceView.imgR_a);
              MySurfaceView.y1=0;
              MySurfaceView.dy1=45;
              MySurfaceView.flag=false;
          }
      }
        );

    }
}